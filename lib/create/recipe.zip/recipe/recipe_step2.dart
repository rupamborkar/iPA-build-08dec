import 'package:flutter/material.dart';
import 'recipe_ingredient_form.dart';

class RecipeStep2 extends StatefulWidget {
  //final VoidCallback onNext;
  final Map<String, dynamic> recipeData;

  const RecipeStep2({super.key, required this.recipeData});

  @override
  _RecipeStep2State createState() => _RecipeStep2State();
}

class _RecipeStep2State extends State<RecipeStep2> {
  List<int> ingredientForms = [0]; // List to manage dynamic forms
  int formCounter = 1; // Counter to give unique keys to each form

  void _addIngredientForm() {
    setState(() {
      ingredientForms.add(formCounter++);
    });
  }

  void _removeIngredientForm(int index) {
    setState(() {
      ingredientForms.remove(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const Text(
                    'Add Ingredients',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: _addIngredientForm,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (ingredientForms.isEmpty)
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.5,
                  child: const Center(
                    child: Text(
                      'Tap the add icon to enter an ingredient.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              else
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: ingredientForms.length,
                  itemBuilder: (context, index) {
                    return Card(
                      elevation: 4,
                      color: const Color.fromRGBO(255, 255, 255, 1),
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RecipeIngredientForm(
                                // widget.recipeData,
                                onSave: (ingredient) =>
                                    widget.recipeData['ingredients']
                                // .add(ingredient),
                                ),
                            const SizedBox(height: 8),
                          ],
                        ),
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}
